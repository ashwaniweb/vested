function calc() {
    var button = document.querySelector("input[type='button']");
    if (button) {
        button.addEventListener("click", buttonClick);
        function buttonClick() {
            var abc = button.value;
            console.log(abc);
        }
    }
}
document.addEventListener("DOMContentLoaded", function() {
    calc();
});

var tax, amount;
function taxes(amt, tax) {
    tax = (amt * tax) / 100;
    return printAmount(amt, tax);
}

function printAmount(amt, tax) {
    return formatAmount(amt, tax, amt + tax);
}

function formatAmount(amount, tax, tAmount) {
    console.log("Gross Amount ₹" + amount);
    console.log("Tax ₹" + tax);
    console.log("Total Amount ₹" + tAmount);
}

function finalPayment(amount, taxPercent) {
    taxes(amount, taxPercent);
}

finalPayment(200, 10);
