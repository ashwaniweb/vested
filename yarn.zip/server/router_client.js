var express = require("express");

module.exports = function(app) {
	var router = express.Router();
	var mainController = require("./controllers/main");

	//DEFAULT CLIENT ENDPOINTS
	//Client Side routing mostly handled by react-router
	router.get("/*", mainController.index);
	router.post("/newsletter", mainController.newsletter);
	app.use("/", router);
};
