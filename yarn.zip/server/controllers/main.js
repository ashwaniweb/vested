var path = require("path");
var nodemailer = require("nodemailer");
var smtpTransport = require("nodemailer-smtp-transport");
var Mailchimp = require("mailchimp-api-v3");

import React from "react";
import Helmet from "react-helmet";
import routes from "../../assets/jsx/router.jsx";
import { renderToString } from "react-dom/server";
import { match, RouterContext } from "react-router";

var MAILCHIMP_KEY = "3d5f55aa6b146b737334ae0ac52ad9f2-us15";

var mailOptions = {
	host: "email-smtp.us-east-1.amazonaws.com",
	port: 587,
	secureConnection: false,
	auth: {
		user: "AKIAJQFF4TARDNIQSIEQ",
		pass: "AoT8DMDrEkmFFL9lE+Pg1ri5xq0fNjBBcePcTExiioYW"
	},
	tls: {
		ciphers: "SSLv3"
	}
};
var smtpTransport = nodemailer.createTransport(mailOptions);

exports.index = function(req, res) {
	match({ routes: routes.routes, location: req.url }, (error, redirectLocation, renderProps) => {
		var ifProduction = process.env.NODE_ENV == "production";
		if (error) {
			res.status(500).send(error.message);
		} else if (redirectLocation) {
			res.redirect(302, redirectLocation.pathname + redirectLocation.search);
		} else if (renderProps) {
			window.location.origin = req.protocol + "://" + req.get("host");
			var reactString = renderToString(<RouterContext {...renderProps} />);
			let head = Helmet.rewind();
			head = {
				title: head.title.toString(),
				meta: head.meta.toString(),
				link: head.link.toString()
			};
			res.render("index", { reactString: reactString, production: ifProduction, head: head });
			// res.status(200).send()
		} else {
			res.status(404).send("Not found");
		}
	});
};

exports.newsletter = function(req, res) {
	let data = {
		email_address: req.body.email,
		status: "subscribed",
		merge_fields: {
			EMAIL: "",
			FNAME: req.body.fname,
			LNAME: req.body.lname,
			COMPANY: req.body.company
		}
	};

	console.log(data);

	var mailchimp = new Mailchimp(MAILCHIMP_KEY);
	mailchimp.post(
		{
			path: "/lists/0169a4d9af/members"
		},
		data,
		function(err, result) {
			res.json({ err, result });
		}
	);
};
