import React from "react";
import { browserHistory, Link } from "react-router";

import Menu from "./components/menu";
import Footer from "./components/footer";
import Modal from "./components/modal";
import Loader from "./components/loader";
import Toast from "./components/toast";

var WebFont = require("webfontloader");
if (document.documentElement) {
	WebFont.load({ typekit: { id: "dfk1hps" } });
}

export default class App extends React.Component {
	state = {
		location: window.location.pathname
	};

	componentDidMount() {
		this._ReactGA = require("react-ga");
		this._ReactGA.initialize("UA-99846828-1");
		this._logPageView();
		// var isIE = /*@cc_on!@*/ false || !!document.documentMode;
		// var isChrome = !!window.chrome && !!window.chrome.webstore;
		// var isOpera =
		//   (!!window.opr && !!opr.addons) ||
		//   !!window.opera ||
		//   navigator.userAgent.indexOf(" OPR/") >= 0;
		// if (isIE) browserHistory.push("/browser-support");
		// if (isOpera) browserHistory.push("/browser-support");
	}

	componentDidUpdate(prevProps, prevState) {
		if (this.state.location != window.location.pathname) {
			this.setState({ location: window.location.pathname });
			this._logPageView();
		}
	}

	_logPageView = () => {
		if (this._ReactGA.set) {
			console.log("LOGGING PAGE VIEW");
			this._ReactGA.set({
				page: window.location.pathname + window.location.search
			});
			this._ReactGA.pageview(window.location.pathname + window.location.search);
		}
	};

	render() {
		return (
			<div id="vested-website-wrapper">
				<Menu />
				{this.props.children}
				<Footer />
				<Modal />
				<Loader />
				<Toast />
			</div>
		);
	}
}
