import React    from 'react'
import {render}	from 'react-dom'

import routes 	from './router'

import {
    browserHistory,
    match,
    Router,
} from 'react-router';

match({ history: browserHistory, routes: routes.routes }, (error, redirectLocation, renderProps) => {
	render(<Router {...renderProps} />, document.getElementById('affinity'))
})
