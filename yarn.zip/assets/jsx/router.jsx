import React from 'react';

import App from './app';
import BrowserSupport from './components/browser-support.jsx';
import Home from './pages/home/home.jsx';
import Employers from './pages/employers/employers.jsx';
import Professionals from './pages/professionals/professionals.jsx';
import Temp from './pages/temp/temp.jsx';
import Consulting from './pages/consulting/consulting.jsx';
import Terms from './pages/documents/terms.jsx';
import Privacy from './pages/documents/privacy.jsx';
import Contact from './pages/contact/contact.jsx';
import FAQ from './pages/documents/faq.jsx';

import { browserHistory, Router, Route, IndexRoute, IndexRedirect } from 'react-router';

const routes = (
    <Router history={browserHistory}>
        <Route path="/" component={App}>
            <IndexRoute component={Home} onEnter={onEnter} />

            <Route path="/employers" component={Employers} onEnter={onEnter} />
            <Route path="/professionals" component={Professionals} onEnter={onEnter} />
            <Route path="/temporary-jobs" component={Temp} onEnter={onEnter} />
            <Route path="/consulting" component={Consulting} onEnter={onEnter} />

            <Route path="/terms-of-service" component={Terms} onEnter={onEnter} />
            <Route path="/privacy-policy" component={Privacy} onEnter={onEnter} />
            <Route path="/faq" component={FAQ} onEnter={onEnter} />
            <Route path="/join-newsletter" component={Contact} onEnter={onEnter} />
            <Route path="/browser-support" component={BrowserSupport} onEnter={onEnter} />
            {/* <Route 			name="404" 				path="*"				component={Error404} 	onEnter={onEnter}/> */}
        </Route>
    </Router>
);

function onEnter(nextState, replace, cb) {
    try {
        document.dispatchEvent(new Event('deactivate'));
        document.dispatchEvent(new Event('scrollToTop'));
    } catch (err) {}
    let timeoutDuration = 500;
    if (nextState.location.action == 'POP') {
        timeoutDuration = 0;
    }
    setTimeout(() => {
        cb();
    }, timeoutDuration);
}

export default { routes };
