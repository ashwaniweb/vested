import React from "react";
import { browserHistory } from "react-router";

export default class ContactForm extends React.Component {
	state = {
		fname: "",
		lname: "",
		email: "",
		company: "",
		type: "",
		comments: ""
	};

	render() {
		return (
			<section className="contact-form" style={{ backgroundColor: this.props.bgColor }}>
				<header>
					<h1> Join Vested's newsletter </h1>
					<p>Join 10,000 finance professionals that receive our newsletter</p>
					<ul>
						<li>Best finance practices, techniques and cutting edge concepts</li>
						<li>Notifications of new career opportunities</li>
						<li>Case studies and Q&As with finance industry leaders</li>
					</ul>
				</header>
				<form>
					<InputField
						label="First Name"
						type="text"
						place="first name"
						value={this.state.fname}
						handleChange={input => {
							this.setState({ fname: input });
						}}
					/>
					<InputField
						label="Last Name"
						tyep="text"
						place="last Name"
						value={this.state.lname}
						handleChange={input => {
							this.setState({ lname: input });
						}}
					/>
					<InputField
						label="Email"
						type="email"
						place="email"
						value={this.state.email}
						handleChange={input => {
							this.setState({ email: input });
						}}
					/>
					<InputField
						label="company"
						type="text"
						place="company"
						value={this.state.company}
						handleChange={input => {
							this.setState({ company: input });
						}}
					/>
				</form>
				<div className="btn-wrap">
					<button className="button bg-fill small" onClick={this._onSubmit}>Join</button>
				</div>
			</section>
		);
	}

	_onSubmit = e => {
		e.preventDefault();
		let errors = this._errors();
		if (errors.length > 0) {
			document.dispatchEvent(
				new CustomEvent("activateModal", {
					detail: <ErrorModal errors={errors} details={this.state} />
				})
			);
			return;
		}
		this._submit();
	};

	_submit = () => {
		let url = "/newsletter";
		var xhr = new XMLHttpRequest();
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
		xhr.send(JSON.stringify(this.state));
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.dispatchEvent(new CustomEvent("activateModal", { detail: <SuccessModal /> }));
			}
		};
		this.setState({
			fname: "",
			lname: "",
			email: "",
			company: "",
			comments: ""
		});
	};

	_emailValidate = email => {
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	};

	_errors = () => {
		let errors = [];

		if (this.state.fname == "") errors.push("First Name Missing");
		if (this.state.lname == "") errors.push("Last Name Missing");
		if (this.state.email == "") errors.push("Email Missing");
		else if (!this._emailValidate(this.state.email)) errors.push("Invalid Email");
		return errors;
		// else return null
	};
}

class InputField extends React.Component {
	render() {
		return (
			<div className="input-field">
				<span className="flex">
					<label>{this.props.label}</label>
					{this._optional()}
				</span>
				<input
					type={this.props.type}
					value={this.props.value}
					placeholder={this.props.place}
					onChange={e => this.props.handleChange(e.target.value)}
				/>
			</div>
		);
	}
	_optional = () => {
		if (this.props.label == "company") {
			return <p className="optional">*optional</p>;
		}
	};
}

class ErrorModal extends React.Component {
	render() {
		return (
			<div className="error-modal flex-center">
				<h2>Looks like there's some errors!!!</h2>
				<ul className="errors">
					{this.props.errors.map((error, i) => {
						return <li key={i}>{error}</li>;
					})}
				</ul>
				<button className="button small" onClick={this._goToContact}>Fill Up Again</button>
			</div>
		);
	}

	_goToContact = () => {
		document.dispatchEvent(new Event("deactivateModal"));
	};
}

class SuccessModal extends React.Component {
	render() {
		return (
			<div className="success-modal flex-center">
				<h2>Signed up successfully !</h2>
				<button className="button small" onClick={this._goToContact}>Close</button>
			</div>
		);
	}

	_goToContact = () => {
		document.dispatchEvent(new Event("deactivateModal"));
	};
}
