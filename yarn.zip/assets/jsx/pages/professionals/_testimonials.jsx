import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

export default class Testimonials extends Component {
    state = {
        active: 0
    };

    componentDidMount() {
        this._slide(this.state.active % this._testimonials.length);
        setTimeout(() => {
            this._slide(this.state.active + 1 % this._testimonials.length);
        }, 2000);
    }

    _testimonials = [
        {
            img: '/img/professionals/testimonial1.jpg',
            text:
                'Vested made it easy to find a new job.  Once my profile was complete, I immediately had companies reaching out to me looking to hire someone with my specific skills and experience.  The process was quick, easy and I’ve already made a big impact at my new company.',
            name: 'Sara, Accounting Manager'
        }
    ];

    render() {
        let currentObj = this._testimonials[this.state.active];
        return (
            <section className="testimonials">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/stories-header.svg"
                        />
                        <h2 className="page-section-header-text blue">Stories</h2>
                    </div>
                    <h3 className="page-section-header-subtitle">Meet Vested’s talent community</h3>
                </div>
                <article className="testimonial">
                    <img src={currentObj.img} />
                    <p dangerouslySetInnerHTML={{ __html: currentObj.text }} />
                    <p className="name">{currentObj.name}</p>
                </article>
                <article className="testimonial">
                    <img src="/img/professionals/testimonial2.jpg" />
                    <p
                        dangerouslySetInnerHTML={{
                            __html:
                                'Advancing my career through Vested was easy and fast. Past attempts required much more time and effort, however, with Vested I was being contacted for jobs within a week.<br/>Vested highlighted my skills and made me stand out to potential employers. I would 10/10 recommend this website to other professionals'
                        }}
                    />
                    <p className="name">Duane, Accountant</p>
                </article>
                {/* <div className="thumbnails">
                    {this._testimonials.map((obj, i) => {
                        return <div key={i} onClick={e=>this._slide(i)} className={(i==this.state.active%this._testimonials.length)?("active"):("")}/>
                    })}
                </div> */}
            </section>
        );
    }

    _slide = i => {
        console.log(i);
        // this.setState({active: i})
        setTimeout(() => {
            this.setState({ active: i });
        }, 100);
    };
}

class Testimonial extends Component {
    render() {
        return (
            <article className="testimonial">
                <img src={this.props.img} />
                <p dangerouslySetInnerHTML={{ __html: this.props.text }} />
                <p className="name">{this.props.name}</p>
            </article>
        );
    }
}
