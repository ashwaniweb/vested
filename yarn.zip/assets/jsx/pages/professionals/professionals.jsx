import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';
import ReadyToGetVested from '../../components/ready-to-get-vested.jsx';
import Testimonials from './_testimonials.jsx';
import Meta from '../../components/meta';
import Results from './_results';
import WhyLove from './_why_candidates';
import Companies from '../home/_companies';

export default class Professionals extends Component {
    state = {
        active: false
    };

    componentDidMount() {
        document.addEventListener('deactivate', () => this.setState({ active: false }));
        setTimeout(() => {
            this.setState({ active: true });
        }, 100);
    }

    render() {
        let metaTitle = 'Vested | Grow your career with Vested';
        let metaDescription = 'Find your next job, grow your skills, showcase your talent';
        let metaImage = window.location.origin + '/img/og.png';
        return (
            <main className={'employers professionals ' + (!this.state.active || 'active')}>
                <Meta title={metaTitle} description={metaDescription} image={metaImage} />
                <Splash />
                <HowItWorks />
                <WhyLove />
                <Testimonials />
                <Results />
                <ReadyToGetVested
                    text="Ready to Get Vested ?"
                    btn="Find A Job"
                    href="/app/candidate/signup"
                    bgImage="/img/professionals/get-ready.jpg"
                />
                <Companies />
            </main>
        );
    }
}

class Splash extends Component {
    state = {
        active: false
    };

    componentDidMount() {
        document.addEventListener('deactivate', () => this.setState({ active: false }));
        setTimeout(() => {
            this.setState({ active: true });
        }, 100);
    }

    render() {
        return (
            <section className={'splash ' + (!this.state.active || 'active')}>
                <img src="/img/home/splash2.jpg" className="splash-bg" />
                <header>Find Your Next Job</header>
                <h2>Skip lengthy screening processeses, connect directly with hiring managers</h2>
                <a href="/app/candidate/signup">
                    <button className="btn-blue rounded">Sign Up</button>
                </a>
            </section>
        );
    }
}

class HowItWorks extends Component {
    render() {
        return (
            <section className="how-it-works" style={{ backgroundColor: '#FFF' }}>
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg className="page-section-header-icon" src="/img/icons/how-header.svg" />
                        <h2 className="page-section-header-text blue">How it works</h2>
                    </div>
                    <h3 className="page-section-header-subtitle">Underneath the hood</h3>
                </div>
                <article className="row reduce">
                    <div className="column">
                        <img src="/img/professionals/Candidate1.jpg" className="full" />
                    </div>
                    <div className="column how-it-works-text">
                        <Svg src="/img/employers/PersonalizeCandidate.svg" />
                        <h2>Personalize</h2>
                        <ul>
                            <li>
                                <em>Tell your story</em> on your personalized Vested profile
                            </li>
                            <li>
                                <em>Companies will apply to you</em> based on their hiring needs
                            </li>
                        </ul>
                    </div>
                </article>
                <article className="row reduce row-reverse">
                    <div className="column">
                        <img src="/img/professionals/Candidate2.jpg" className="full" />
                    </div>
                    <div className="column how-it-works-text">
                        <Svg src="/img/professionals/Professional2.svg" />
                        <h2>Communicate</h2>
                        <ul>
                            <li>
                                Check your profile and <em>accept interview requests</em> for roles
                                that you find exciting
                            </li>
                            <li>
                                Reach out to our <em>talent ambassadors</em> at any time with
                                questions
                            </li>
                        </ul>
                    </div>
                </article>
            </section>
        );
    }
}

class Stats extends Component {
    render() {
        return (
            <section className="stats">
                <div className="box">
                    <h1 className="big"> 35 </h1>
                    <h4>Avg. days to hire</h4>
                </div>
                <div className="box">
                    <h1 className="big"> $105,636 </h1>
                    <h4>Avg. salary</h4>
                </div>
            </section>
        );
    }
}
