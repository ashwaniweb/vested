import React, { Component } from 'react';

const COMPANIES = [
    '/img/companies/bulldog.png',
    // '/img/companies/industrious.png',
    '/img/companies/cybernet.png',
    '/img/companies/rewardable.png',
    '/img/companies/fluent_city.png',
    '/img/companies/calyx.png',
    '/img/companies/aaptiv.png',
    '/img/companies/paskho.png',
    '/img/companies/skymark.png'
];

export default class Companies extends Component {
    render() {
        return (
            <div className="companies">
                <div className="companies-strip">
                    {COMPANIES.concat(COMPANIES)
                        .concat(COMPANIES)
                        .concat(COMPANIES)
                        .map((company, i) => (
                            <div key={i} className="company">
                                <img
                                    className="company-image"
                                    src={company}
                                    alt={company.split('/')[COMPANIES.length - 1]}
                                />
                            </div>
                        ))}
                </div>
            </div>
        );
    }
}
