import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'Trusted advice at a fraction of the cost',
        icon: '/img/grid/trusted.svg',
        description:
            'Work with top-tier professionals to solve specific problems without the overhead of multinational advisory firms'
    },
    {
        title: 'Match with experts that are aligned with your needs',
        icon: '/img/grid/match.svg',
        description:
            'The Vested platform continues to sort experts into specific and narrow categories to ensure maximum impact'
    },
    {
        title: 'We curate and vet only the best talent',
        icon: '/img/grid/customized.svg',
        description:
            'The Vested platform uses a combination of machine learning and human touch to ensure our network is of highest quality'
    }
];

export default class WhyClients extends Component {
    render() {
        return (
            <div className="why-clients page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/why-clients-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Why Our<strong> Clients</strong> Love Us
                        </h2>
                    </div>
                </div>
                <div className="page-section-cards">
                    {ITEMS.map((card, i) => <WhyClientsCard key={i} {...card} />)}
                </div>
            </div>
        );
    }
}

const WhyClientsCard = ({ title, description, icon }) => (
    <div className="page-section-card">
        <Svg className="page-section-card-icon" src={icon} />
        <div className="page-section-card-title">{title}</div>
        <div className="page-section-card-description">{description}</div>
    </div>
);
