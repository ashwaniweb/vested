import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'Finance',
        items: [
            'FP&A transformation',
            'Fundraising',
            'Valuation',
            'Acquisition Due Diligence',
            'Financial Modeling'
        ]
    },
    {
        title: 'Accounting',
        items: [
            'Policies and procedures implementation',
            'ERP software',
            'Billing and receivable software',
            'Payroll / HR / Insurance',
            'Working capital specialists'
        ]
    },
    {
        title: 'Tax',
        items: [
            'Regulatory change',
            'International tax',
            'Tax planning and compliance',
            'State and Federal tax',
            'Sales tax'
        ]
    }
];

export default class Roles extends Component {
    render() {
        return (
            <div className="what-we-do page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <h2
                            className="page-section-header-text-alternate"
                            style={{ color: '#4A4A4A' }}
                        >
                            Specific Project Needs
                        </h2>
                        <h2 className="page-section-header-subtitle">
                            The Vested network has experts across several categories
                        </h2>
                    </div>
                </div>
                <div className="page-section-simple-grid">
                    {ITEMS.map((gridItem, i) => <RolesGridItem key={i} {...gridItem} />)}
                </div>
            </div>
        );
    }
}

const RolesGridItem = ({ title, items }) => (
    <div className="page-section-simple-grid-item">
        <div className="page-section-simple-grid-item-title">{title}</div>
        <div className="page-section-simple-grid-item-list">
            {items.map((item, i) => (
                <span className="page-section-simple-grid-item-list-item">{item}</span>
            ))}
        </div>
    </div>
);
