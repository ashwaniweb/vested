import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'Connect With Change Agents',
        icon: '/img/icons/connect.svg',
        description:
            'Connect with the right talent to help you solve critical finance and accounting challenges that arise from growth or regulatory changes'
    },
    {
        title: 'Leverage Our Large Network',
        icon: '/img/icons/leverage.svg',
        description:
            'We have curated and vetted a deep bench of finance and accounting professionals that are ready to help you with your critical challenges'
    },
    {
        title: 'Consulting Engagements Tailored To Your Needs',
        icon: '/img/icons/consulting.svg',
        description:
            'Our platform enables you to work with consultants on your schedule - from hourly, weekly and monthly engagements'
    }
];

export default class WhatWeDo extends Component {
    render() {
        return (
            <div className="what-we-do page-section">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg className="page-section-header-icon" src="/img/icons/how-header.svg" />
                        <h2 className="page-section-header-text">
                            How it <strong>Works</strong>
                        </h2>
                    </div>
                </div>
                <div className="page-section-grid">
                    {ITEMS.map((gridItem, i) => <WhatWeDoGridItem key={i} {...gridItem} />)}
                </div>
                <div className="page-section-contact-us">
                    <button className="btn-blue">Contact Us</button>
                    <span>Connect with us to help you find an expert</span>
                </div>
            </div>
        );
    }
}

const WhatWeDoGridItem = ({ title, description, icon }) => (
    <div className="page-section-grid-item with-icon">
        <Svg className="page-section-grid-item-icon" src={icon} />
        <div className="page-section-grid-item-text">
            <div className="page-section-grid-item-title">{title}</div>
            <div className="page-section-grid-item-description">{description}</div>
        </div>
    </div>
);
