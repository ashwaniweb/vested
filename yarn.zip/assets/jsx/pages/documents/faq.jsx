import React from "react";

export default class FAQ extends React.Component {
	state = {
		active: false
	};

	componentDidMount() {
		document.addEventListener("deactivate", () => this.setState({ active: false }));
		setTimeout(() => {
			this.setState({ active: true });
		}, 100);
	}

	render() {
		return (
			<section className={"terms " + (!this.state.active || "active")}>
				<h1>FAQ for candidates</h1>
				<div className="anchors">
					<a className="anchor" href="#how-does-vested-work">
						How does Vested work?
					</a>
					<a className="anchor" href="#what-are-the-benefits">
						What are the benefits of using Vested?
					</a>
					<a className="anchor" href="#what-kind-of-jobs">
						What kind of jobs are you hiring for?
					</a>
					<a className="anchor" href="#approval-process">
						What is the approval process for candidates and companies?
					</a>
					<a className="anchor" href="#interview-invite">
						What happens when I receive an interview invite?{" "}
					</a>
					<a className="anchor" href="#specific-positions">
						Can I apply to specific positions?
					</a>
					<a className="anchor" href="#hide-from-companies">
						My current company uses Vested.  Will they be able to see my profile?
					</a>
					<a className="anchor" href="#opportunities-today">
						Where do you have opportunities today?
					</a>
					<a className="anchor" href="#misc">
						Need help with something else?
					</a>
				</div>

				<a name="how-does-vested-work" />
				<h2>How does Vested work?</h2>
				<p>
					Vested helps connect talented finance and accounting professionals to the best companies.  Just follow the steps below to find new job opportunities:
				</p>
				<ul>
					<li>
						Register with your personal email for a new account at the link below:
						<br />
						<a href="/app/candidate/signup" target="_blank">getvested.io/app/candidate/signup</a>
					</li>
					<li>
						Walk through the guided onboarding process and provide us with your skills, experience, and prior work history to complete your profile.  We recommend filling out every detail (including adding a photo) which will make you stand out to amazing companies.
					</li>
					<li>
						After completing your profile, you’ll be asked to verify your email before your account goes live.  We do this to ensure we have a way to contact you when a hiring manager requests an interview with you.
					</li>
					<li>
						A Talent Ambassador will reach out to you shortly after your account goes live to check in and ensure that everything looks good on our end.
					</li>
					<li>
						Based on your unique work history and the skills that you’ve gained over your career, our algorithms present your profile to companies that could leverage you the most.  For instance, if you have audit experience, we present you to companies that are soon to go public.
					</li>
					<li>
						We will automatically notify you when a company is interested in you.  Our talent ambassadors will facilitate the interview process.
					</li>
				</ul>
				<a name="what-are-the-benefits" />
				<h2>What are the benefits of using Vested?</h2>
				<p>
					Unlike traditional recruiters or job searches, Vested makes companies apply to you by showcasing your profile to the companies that need your skills the most.  We also curate a variety of opportunities for our candidates at high caliber companies.  Additionally, our platform provides you transparency around things like salary, equity, and specific skills that are required so you can make your next career move with confidence.   Our Talent Ambassadors’ primary goal is to help you find the right job.  Oh, and one more thing, for our early adopters, we are offering a $1,000 hiring bonus for getting hired through Vested!
				</p>
				<a name="what-kind-of-jobs" />
				<h2>What kind of jobs are you hiring for?</h2>
				<p>
					Companies come to us to help find candidates that are finance and accounting superstars.  We place entry level job seekers all the way up to C-level execs, although our sweet spot is in the 2 - 8 years of experience range.
				</p>
				<a name="approval-process" />
				<h2>What is the approval process for candidates and companies?</h2>
				<p>
					Both candidates and companies are thoroughly vetted before they are able to use Vested. Candidates must have a complete profile and demonstrable skills for a high-demand role.  Companies must be venture backed or publicly traded, and be willing to provide compensation and role details in the offers they make on our platform.  We only onboard the best companies so our candidates have the best experience on our platform.
					{" "}
				</p>
				<a name="interview-invite" />
				<h2>What happens when I receive an interview invite? </h2>
				<p>
					In the event there is a job opportunity that fits your skillset, you’ll receive a message from Vested about the position. The offer will be from a company that is either venture backed or publically traded, and will include compensation and role details.
					{" "}
				</p>
				<p>
					If you decide to accept the interview opportunity, our Talent Ambassadors will reach out to you and schedule a time to speak with the company.  The interview process will be driven by the hiring manager where you will most likely undergo a combination of a phone meeting and a few rounds of on-site interviews.  We’ll be in touch throughout to ensure that the process goes smoothly on your end.
				</p>
				<a name="specific-positions" />
				<h2>Can I apply to specific positions?</h2>
				<p>
					Vested doesn’t operate like a job board.  Our platform uses a combination of technology and human touch to connect you with opportunities where you can make the biggest impact.  As we mentioned above, we’ll reach out to you when we have a potential fit.
				</p>
				<a name="hide-from-companies" />
				<h2>My current company uses Vested.  Will they be able to see my profile?</h2>
				<p>
					We actively hide your profile from any current or former employers. We also have a feature that allows you to hide yourself from other employers of your choosing.
				</p>
				<a name="opportunities-today" />
				<h2>Where do you have opportunities today?</h2>
				<p>
					Currently, Vested operates in NYC, Chicago, and San Francisco.  We will soon be launching in additional cities. If you're outside of our current geography please include the city you live in when building your profile.
				</p>
				<a name="misc" />
				<h2>Need help with something else?</h2>
				<p>
					Drop us a note at:<a href="mailto://hello@getvested.io"> hello@getvested.io </a>
				</p>
				<br />
				<br />
				<p>
					Please email us at
					<a href="mailto://hello@getvested.io"> hello@getvested.io </a>
					for any more questions. We would be happy to assist you.
				</p>
			</section>
		);
	}
}
