import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'HIRE FASTER AND BETTER',
        icon: '/img/grid/hire.svg',
        description:
            'Our software platform and matching algorithms cultivate top-tier talent allowing you to hire quickly and efficiently'
    },
    {
        title: 'CUSTOMIZED RECRUITMENT FLOW',
        icon: '/img/grid/customized.svg',
        description:
            'We work with you to create qualitative and quantitative screens for candidates as they flow through various stages of your hiring funnel'
    },
    {
        title: 'ALWAYS IMPROVING',
        icon: '/img/grid/always.svg',
        description:
            'Our matching algorithms are continually improving and adding new layers to deliver the best candidates for your business'
    }
];

export default class WhyClients extends Component {
    render() {
        return (
            <div className="why-clients page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/why-clients-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Why Our<strong> Clients</strong> Love Us
                        </h2>
                    </div>
                </div>
                <div className="page-section-cards">
                    {ITEMS.map((card, i) => <WhyClientsCard key={i} {...card} />)}
                </div>
            </div>
        );
    }
}

const WhyClientsCard = ({ title, description, icon }) => (
    <div className="page-section-card">
        <Svg className="page-section-card-icon" src={icon} />
        <div className="page-section-card-title">{title}</div>
        <div className="page-section-card-description">{description}</div>
    </div>
);
