import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'AUTOMATE THE RECRUITMENT PROCESS',
        description:
            'Our algorithms match talent to your openings based on several qualitative and quantitative metrics '
    },
    {
        title: 'BREAK OPENINGS INTO REQUIRED SKILLS',
        description:
            'We work with businesses to help them identify their ideal finance and accounting candidate profile'
    },
    {
        title: 'QUALIFY TOP-TIER TALENT',
        description:
            'Candidates are screened using qualitative and quantitative assessments that maximize impact and reduce turnover'
    },
    {
        title: 'RESEARCH AND THOUGHT LEADERSHIP',
        description:
            'We provide both candidates and hiring managers with best practices to navigate the most challenging talent acquisition processes'
    }
];

export default class WhatWeDo extends Component {
    render() {
        return (
            <div className="what-we-do page-section">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/what-we-do-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            What <strong>We</strong> Do
                        </h2>
                    </div>
                </div>
                <div className="page-section-grid">
                    {ITEMS.map((gridItem, i) => <WhatWeDoGridItem key={i} {...gridItem} />)}
                </div>
            </div>
        );
    }
}

const WhatWeDoGridItem = ({ title, description }) => (
    <div className="page-section-grid-item">
        <div className="page-section-grid-item-title">{title}</div>
        <div className="page-section-grid-item-description">{description}</div>
    </div>
);
