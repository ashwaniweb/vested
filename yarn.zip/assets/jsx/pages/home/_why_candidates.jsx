import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'ONE APPLICATION, MULTIPLE OPPORTUNITIES',
        icon: '/img/grid/one.svg',
        description:
            'We know you’re busy, so use one application to connect to multiple job opportunities '
    },
    {
        title: 'TOP COMPANIES USE VESTED',
        icon: '/img/grid/top.svg',
        description:
            'We connect you with only the highest quality companies - from household names to emerging startups, and everything in between'
    },
    {
        title: 'WE’RE YOUR BIGGEST ADVOCATE',
        icon: '/img/grid/were.svg',
        description:
            'We know that all businesses need finance and accounting leaders to build great businesses. We’re finance professionals too and empathize with your journey'
    }
];

export default class WhyCandidates extends Component {
    render() {
        return (
            <div className="why-candidates page-section">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/why-candidates-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Why Our<strong> Candidates</strong> Love Us
                        </h2>
                    </div>
                </div>
                <div className="page-section-cards">
                    {ITEMS.map((card, i) => <WhyCandidatesCard key={i} {...card} />)}
                </div>
            </div>
        );
    }
}

const WhyCandidatesCard = ({ title, description, icon }) => (
    <div className="page-section-card">
        <Svg className="page-section-card-icon" src={icon} />
        <div className="page-section-card-title">{title}</div>
        <div className="page-section-card-description">{description}</div>
    </div>
);
