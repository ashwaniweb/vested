import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';
import ReadyToGetVested from '../../components/ready-to-get-vested.jsx';
import Meta from '../../components/meta';
import WhyClients from './_why_clients';
import Results from './_results';

export default class Employers extends Component {
    state = {
        active: false
    };

    componentDidMount() {
        document.addEventListener('deactivate', () => this.setState({ active: false }));
        setTimeout(() => {
            this.setState({ active: true });
        }, 100);
    }

    render() {
        let metaTitle = 'Vested | Find the best talent';
        let metaDescription = 'Hire Outstanding Finance & Accounting Talent';
        let metaImage = window.location.origin + '/img/og.png';
        return (
            <main className={'employers ' + (!this.state.active || 'active')}>
                <Meta title={metaTitle} description={metaDescription} image={metaImage} />
                <Splash />
                <HowItWorks />
                <WhyClients />
                <Results />
                <ReadyToGetVested
                    text="Ready to Get Vested?"
                    btn="Start Hiring"
                    href="/app/client/signup"
                    bgImage="/img/employers/get-ready-bg.jpg"
                />
            </main>
        );
    }
}

class Splash extends Component {
    state = {
        active: false
    };

    componentDidMount() {
        document.addEventListener('deactivate', () => this.setState({ active: false }));
        setTimeout(() => {
            this.setState({ active: true });
        }, 100);
    }

    render() {
        return (
            <section className={'splash ' + (!this.state.active || 'active')}>
                <img src="/img/home/splash2.jpg" className="splash-bg" />
                <header>
                    Find the best talent with <em>Vested</em>
                </header>
                <h2>Hire Outstanding Finance Talent </h2>
                <a href="/app/client/signup">
                    <button className="btn-blue rounded">start hiring</button>
                </a>
            </section>
        );
    }
}

class HowItWorks extends Component {
    render() {
        return (
            <section className="how-it-works" style={{ backgroundColor: '#FFF' }}>
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg className="page-section-header-icon" src="/img/icons/how-header.svg" />
                        <h2 className="page-section-header-text blue">How it works</h2>
                    </div>
                    <h3 className="page-section-header-subtitle">Underneath the hood</h3>
                </div>
                <article className="row reduce">
                    <div className="column">
                        <img src="/img/employers/Employer1.jpg" className="full" />
                    </div>
                    <div className="column how-it-works-text">
                        <Svg src="/img/employers/Employer1.svg" />
                        <h2>Showcase</h2>
                        <ul>
                            <li>
                                Create your company brand with a profile that showcases your{' '}
                                <em> culture, mission and values</em>
                            </li>
                            <li>
                                Provide <em>company-specific</em> information that will help us
                                match the right candidates to your openings
                            </li>
                        </ul>
                    </div>
                </article>
                <article className="row reduce row-reverse">
                    <div className="column">
                        <img src="/img/employers/Employer2.jpg" className="full" />
                    </div>
                    <div className="column how-it-works-text">
                        <Svg src="/img/employers/Employer2.svg" />
                        <h2>Connect</h2>
                        <ul>
                            <li>
                                Post job openings and let our algorithms deliver top candidates that{' '}
                                <em>have specific skills and experience</em> that match your
                                company's needs
                                <p>(we accept only 8% of candidates that apply to our platform)</p>
                            </li>
                            <li>
                                Send <em>personalized interview requests</em> to your favorite
                                candidates or bookmark candidates to review later
                            </li>
                            <li>
                                Streamline the interview process and present an offer to the{' '}
                                <em>right candidate</em>
                            </li>
                        </ul>
                    </div>
                </article>
            </section>
        );
    }
}
