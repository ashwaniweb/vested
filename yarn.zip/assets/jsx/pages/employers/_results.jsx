import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        icon: '/img/icons/seventy.svg',
        description: 'decrease in the time to hire when a company works with Vested'
    },
    {
        icon: '/img/icons/tenkay.svg',
        description: 'candidates screened through Vested’s matching algorithm'
    },
    {
        icon: '/img/icons/fifty.svg',
        description: 'cost savings as compared to traditional recruiting methods'
    }
];

export default class Results extends Component {
    render() {
        return (
            <div className="why-clients page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/results-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            <strong>Results</strong>
                        </h2>
                    </div>
                    <h3 className="page-section-header-subtitle">
                        Here's what companies have seen using Vested
                    </h3>
                </div>
                <div className="page-section-stats">
                    {ITEMS.map((card, i) => <ResultsStat key={i} {...card} />)}
                </div>
            </div>
        );
    }
}

const ResultsStat = ({ title, description, icon }) => (
    <div className="page-section-stat">
        <Svg className="page-section-stat-icon" src={icon} />
        <div className="page-section-stat-description">{description}</div>
    </div>
);
