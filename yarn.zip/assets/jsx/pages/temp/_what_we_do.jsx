import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'Fill Your Temporary Roles With The Best Talent',
        description:
            'Our platform leverages matching algorithms to quickly fill your temporary openings with the best talent suited for the role'
    },
    {
        title: 'Leverage Our Large Candidate Database',
        description:
            'We have curated a deep bench of top-tier candidates that are ready for new opportunities'
    },
    {
        title: 'The Human Touch',
        description: 'Our client team is always there to guide you through a perfect placement'
    },
    {
        title: 'Vested In Your Success',
        description:
            'We partner with our candidates and clients to understand both sides of the marketplace to ensure a successful placement'
    }
];

export default class WhatWeDo extends Component {
    render() {
        return (
            <div className="what-we-do page-section">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/what-we-do-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            What <strong>We</strong> Do
                        </h2>
                    </div>
                </div>
                <div className="page-section-grid">
                    {ITEMS.map((gridItem, i) => <WhatWeDoGridItem key={i} {...gridItem} />)}
                </div>
            </div>
        );
    }
}

const WhatWeDoGridItem = ({ title, description }) => (
    <div className="page-section-grid-item">
        <div className="page-section-grid-item-title">{title}</div>
        <div className="page-section-grid-item-description">{description}</div>
    </div>
);
