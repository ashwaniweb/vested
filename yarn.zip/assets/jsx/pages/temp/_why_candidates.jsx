import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'ONE APPLICATION, MULTIPLE OPPORTUNITIES',
        icon: '/img/grid/one.svg',
        description:
            'We know you’re busy, so use one application to connect to multiple job opportunities '
    },
    {
        title: 'TOP-TIER COMPANIES',
        icon: '/img/grid/top-tier.svg',
        description: 'Find your next opportunity at a fast-growth, quality company'
    },
    {
        title: 'A BRIDGE TO A PERMANENT OPPORTUNITY',
        icon: '/img/grid/bridge-permanent.svg',
        description:
            'Leverage temporary positions to gain new skills and transition to permanent opportunities'
    }
];

export default class WhyCandidates extends Component {
    render() {
        return (
            <div className="why-candidates page-section">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/why-candidates-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Why Our<strong> Candidates</strong> Love Us
                        </h2>
                    </div>
                </div>
                <div className="page-section-cards">
                    {ITEMS.map((card, i) => <WhyCandidatesCard key={i} {...card} />)}
                </div>
            </div>
        );
    }
}

const WhyCandidatesCard = ({ title, description, icon }) => (
    <div className="page-section-card">
        <Svg className="page-section-card-icon" src={icon} />
        <div className="page-section-card-title">{title}</div>
        <div className="page-section-card-description">{description}</div>
    </div>
);
