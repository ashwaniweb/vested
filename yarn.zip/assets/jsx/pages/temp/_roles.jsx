import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'Accounting',
        description:
            'Ensure continuity in your month-end close process and financial statement preparation'
    },
    {
        title: 'Financial Analysis',
        description:
            'Discover opportunities to grow your business profitably via forecasting, financial modeling, and KPI tracking'
    },
    {
        title: 'Strategy & Fundraising',
        description: 'Maximize the value of your business during the capital raise process'
    }
];

export default class Roles extends Component {
    render() {
        return (
            <div className="what-we-do page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/what-we-do-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Roles <strong>We</strong> Can Help With
                        </h2>
                    </div>
                </div>
                <div className="page-section-grid">
                    {ITEMS.map((gridItem, i) => <RolesGridItem key={i} {...gridItem} />)}
                </div>
            </div>
        );
    }
}

const RolesGridItem = ({ title, description }) => (
    <div className="page-section-white-grid-item">
        <div className="page-section-white-grid-item-title">{title}</div>
        <div className="page-section-white-grid-item-description">{description}</div>
    </div>
);
