import React, { Component } from 'react';
import Svg from '../../components/svg.jsx';

const ITEMS = [
    {
        title: 'Leverage Vested’s AI',
        icon: '/img/grid/leverage.svg',
        description:
            'Vanilla temporary placement agencies are just hustling bodies. We leverage our existing AI to find the best candidate for your temporary role'
    },
    {
        title: 'Curated and Vetted Candidates',
        icon: '/img/grid/curated.svg',
        description:
            'We vet all of our candidates with the same scrutiny whether they are searching for a temporary or permanent role'
    },
    {
        title: 'Customized Recruitment Flow',
        icon: '/img/grid/customized.svg',
        description:
            'Our platform allows you to create quantitative and qualitative screens to identify your ideal candidates'
    }
];

export default class WhyClients extends Component {
    render() {
        return (
            <div className="why-clients page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/why-clients-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Why Our<strong> Clients</strong> Love Us
                        </h2>
                    </div>
                </div>
                <div className="page-section-cards">
                    {ITEMS.map((card, i) => <WhyClientsCard key={i} {...card} />)}
                </div>
            </div>
        );
    }
}

const WhyClientsCard = ({ title, description, icon }) => (
    <div className="page-section-card">
        <Svg className="page-section-card-icon" src={icon} />
        <div className="page-section-card-title">{title}</div>
        <div className="page-section-card-description">{description}</div>
    </div>
);
