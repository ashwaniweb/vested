import React, { Component } from 'react';
import { Parallax, Background } from 'react-parallax';

import Svg from '../../components/svg';
import Affiliates from '../../components/affiliates';
import Meta from '../../components/meta';

import Companies from './_companies';
import WhatWeDo from './_what_we_do';
import Roles from './_roles';
import WhyClients from './_why_clients';
import WhyCandidates from './_why_candidates';

export default class Home extends Component {
    state = {
        active: false
    };

    componentDidMount() {
        document.addEventListener('deactivate', () => this.setState({ active: false }));
        setTimeout(() => {
            this.setState({ active: true });
        }, 100);
    }

    render() {
        let metaTitle = 'Vested | Your Dream Finance Job Awaits';
        let metaDescription =
            'Vested matches talented finance and accounting professionals with the fastest growing startups';
        let metaImage = window.location.origin + '/img/og.png';

        return (
            <main className={'home ' + (!this.state.active || 'active')}>
                <Meta title={metaTitle} description={metaDescription} image={metaImage} />
                <Splash />
                <div className="companies">
                    <div className="companies-strip"></div>
                </div>
                {/* <Companies /> */}
                <WhatWeDo />
                <WhyClients />
                <WhyCandidates />
                <Roles />
            </main>
        );
    }
}

class Splash extends Component {
    state = {
        active: false
    };

    componentDidMount() {
        document.addEventListener('deactivate', () => this.setState({ active: false }));
        setTimeout(() => {
            this.setState({ active: true });
        }, 100);
    }

    render() {
        let activeClassName = this.state.active ? 'active-bgimage' : '';
        return (
            <Parallax
                strength={100}
                bgImage="/img/home/splash2.jpg"
                bgWidth="100%"
                id="splash"
                className={activeClassName}
            >
                <Background>
                    <Svg src="/img/home/bulb.svg" className={'splash-svg '} />
                </Background>
                <section className={'home-splash ' + (!this.state.active || 'active')}>
                    {/* <img src="/img/home/splash.jpg" alt="Your dream finace job awaits" className="splash-bg" /> */}
                    <div className="splash-text">
                        <h1>Hire On Demand Finance and Accounting Talent </h1>
                        <h2>
                            Vested matches top-tier finance and accounting talent to your temporary
                            or part-time hiring needs
                        </h2>
                        <a href="/app/candidate/signup">
                            <button className="">Find Talent</button>
                        </a>
                        <a href="/app/client/signup">Or, are you a finance or accounting pro?</a>
                    </div>
                </section>
            </Parallax>
        );
    }
}

class Impact extends Component {
    render() {
        return (
            <section className="impact bg-color">
                <h2>
                    Make the <em>GREATEST</em> <strong>impact</strong>
                </h2>
                <h4>We match you to startups where you can have the greatest impact</h4>
                <div className="row">
                    <div className="column">
                        <Svg src="/img/home/FinanceSpecific.svg" />
                        <span className="text">
                            Finance-Specific <br /> Career Platform
                        </span>
                    </div>
                    <div className="column">
                        <Svg src="/img/home/SinglePersonalized.svg" />
                        <span className="text">
                            Single, Personalized <br />Application
                        </span>
                    </div>
                    <div className="column">
                        <Svg src="/img/home/OpportunitiesBest.svg" />
                        <span className="text">
                            Opportunities from <br />the Best Startups
                        </span>
                    </div>
                </div>
            </section>
        );
    }
}

class ImpactfulRoles extends Component {
    render() {
        return (
            <section className="impactful-roles page-section white">
                <div className="page-section-header">
                    <div className="page-section-header-wrapper">
                        <Svg
                            className="page-section-header-icon"
                            src="/img/icons/impact-header.svg"
                        />
                        <h2 className="page-section-header-text">
                            Impactful<strong> Roles</strong> At
                        </h2>
                    </div>
                </div>
                <div className="row">
                    <div className="column">
                        <img src="/img/home/accounting.jpg" />
                        <div className="role">
                            <Svg src="/img/home/Finance.svg" />
                            <h3>Wall Street</h3>
                        </div>
                    </div>
                    <div className="column">
                        <img src="/img/home/finance.jpg" />
                        <div className="role">
                            <Svg src="/img/icons/fortune.svg" />
                            <h3>Fortune 500s</h3>
                        </div>
                    </div>
                    <div className="column">
                        <img src="/img/home/tax.jpg" />
                        <div className="role">
                            <Svg src="/img/icons/bulb.svg" />
                            <h3>Venture Funded Startups</h3>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}
