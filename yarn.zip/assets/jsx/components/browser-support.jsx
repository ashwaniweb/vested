import React, { Component } from "react";

export default class BrowserSupport extends Component {
	render() {
		return (
			<section className="browser-page">
				<h2><em>Upgrade Browser</em> for full Vested Experience</h2>
				<h4>
					It appears that you're using an unsupported browser or are browsing in private mode without cookies. Please use one of our supported browsers in a standard browsing window that allows cookies.
				</h4>
				<div className="row-browser">
					<img src="/img/general/chrome-icon.png" />
					<img src="/img/general/firefox-icon.png" />
					<img src="/img/general/safari-icon.png" />
					{/* <img src="/img/general/edge-icon.png" /> */}
				</div>
				<p className="browser-footer">
					Feel that you're seeing this message in error, contact us at
					<em> hello@getvested.io</em>
				</p>
			</section>
		);
	}
}
