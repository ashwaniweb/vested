import React	from 'react'
import Svg		from './svg'

export default class Affiliates extends React.Component {
	render () {
		return (
			<section className="section grey">
				<h2 className="header"> Our Affiliates </h2>
				<div className="row">
					<div className="column affiliate">
						<h2> Cynet <strong>Systems</strong></h2>
						<h3> IT and Engineering Staffing Division </h3>
						<button></button>
					</div>
					<div className="column affiliate">
						<h2> Cynet <strong>Healthstaff</strong></h2>
						<h3> Healthcare Staffing Division </h3>
						<button></button>
					</div>
				</div>
			</section>
		)
	}
}
