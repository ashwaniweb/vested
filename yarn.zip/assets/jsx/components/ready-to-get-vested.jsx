import React, { Component } from "react";

export default class ReadyToGetVested extends Component {
	render() {
		return (
			<section className="ready row" style={{ backgroundImage: "url(" + this.props.bgImage + ")" }}>
				{/* <img src={this.props.bgImage}/> */}
				<h1>{this.props.text}</h1>
				<a href={this.props.href}><button className="btn-white">{this.props.btn}</button></a>
			</section>
		);
	}
}
