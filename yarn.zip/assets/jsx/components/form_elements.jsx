import React from 'react';

export class LineInput extends React.Component {
	render () {
		return (
			<div className="line-input">
				<label> {this.props.title} </label>
				<input type="text" onChange={this.props.onChange} value={this.props.value} placeholder={this.props.title}/>
			</div>
		)
	}
}

export class MultiLineInput extends React.Component {
	render () {
		return (
			<div className="multi-line-input">
				<label> {this.props.title} </label>
				<textarea onChange={this.props.onChange} value={this.props.value} placeholder={this.props.title}/>
			</div>
		)
	}
}

export class RadioInput extends React.Component {
	render () {
		return (
			<div className="radio-input">
				<label> {this.props.title} </label>
				<RadioInputItem onClick={e=>this.props.onChange(true)} text="Yes" active={this.props.value}/>
				<RadioInputItem onClick={e=>this.props.onChange(false)} text="No"  active={!this.props.value} className="last"/>
			</div>
		)
	}
}

class RadioInputItem extends React.Component {
	render () {
		let activeClassName = (this.props.active)?("active"):("");
		return (
			<div onClick={this.props.onClick} className={"radio-input-item "+this.props.className+" "+activeClassName}>
				<div className="radio"/>
				<p>{this.props.text}</p>
			</div>
		)
	}
}
