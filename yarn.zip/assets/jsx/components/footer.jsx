import React from 'react';
import { browserHistory, Link } from 'react-router';
import Svg from './svg';

export default class Footer extends React.Component {
    render() {
        return (
            <footer className="footer">
                {this._renderNewsletterCTA()}
                <Links />
                <Policy />
            </footer>
        );
    }

    _renderNewsletterCTA = () => {
        if (window.location.pathname != '/join-newsletter') {
            return (
                <div className="join-newsletter">
                    <h1>Join Vested's newsletter</h1>
                    <p>Join 10,000 finance professionals that receive our newsletter</p>
                    <Link to="/join-newsletter">
                        {' '}
                        <button>Subscribe</button>{' '}
                    </Link>
                </div>
            );
        } else return null;
    };
}

class Links extends React.Component {
    render() {
        return (
            <div className="links">
                <div className="site-map">
                    <Link to="/professionals">
                        <span> Professionals </span>
                    </Link>
                    <Link to="/employers">
                        <span> Employers </span>
                    </Link>
                    <Link to="/consulting">
                        <span> Consulting </span>
                    </Link>
                    <Link to="/temporary-jobs">
                        <span> Temporary </span>
                    </Link>
                    <a href="https://getvested.io/blog/" target="_blank">
                        <span> Blog </span>
                    </a>
                    <Link to="/faq">
                        <span> FAQ </span>
                    </Link>
                </div>
                <div className="social">
                    <span> FOLLOW US </span>
                    <a href="https://www.facebook.com/VestedTech/" target="_blank">
                        <Svg src="/img/general/Facebook.svg" />
                    </a>
                    <a href="https://twitter.com/VestedHR" target="_blank">
                        <Svg src="/img/general/Twitter.svg" />
                    </a>
                    <a href="https://www.linkedin.com/company/vestedtechnology" target="_blank">
                        <Svg src="/img/general/Linkedin.svg" />
                    </a>
                </div>
            </div>
        );
    }
}

class Policy extends React.Component {
    render() {
        return (
            <div className="policy">
                <div className="col">
                    {/* <img src="/img/general/logo.svg" /> */}
                    <Link to="/terms-of-service">
                        <span>Terms of Service</span>
                    </Link>
                    <Link to="/privacy-policy">
                        <span>Privacy Policy</span>
                    </Link>
                </div>
                <div className="copyright">
                    <span>© Copyright Vested Technology {new Date().getFullYear()}</span>
                </div>
            </div>
        );
    }
}
